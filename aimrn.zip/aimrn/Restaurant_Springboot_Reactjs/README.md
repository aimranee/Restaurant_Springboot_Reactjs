# Restaurant_Springboot_Reactjs


1. Change NavBar
2. Logo (ansiftoo lik whatsapp)
3. Button (style)
4. Page index 7et fiha chi7ajaa labant liik easy
5. Ordre dyal les pages bdelhoom la7efdeeek
6. Size dyaal les component pllllz (be3dhoom her shwiyaa 3elaa jenaab dyaal lpage sf)

Chokraaaane bzzzzzzzf pllz matkhdemch fiih bzzf her 1h au max
