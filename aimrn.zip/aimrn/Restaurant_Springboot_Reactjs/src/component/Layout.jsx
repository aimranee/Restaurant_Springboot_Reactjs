import React from "react";
import * as mdb from "mdb-ui-kit";
import { Input } from "mdb-ui-kit";
import '../cssglobal.css';

import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import { NavLink } from "react-router-dom";

function Header() {
  return (
    <div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom bg-dark">
      <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <span class="fs-4 text-light">Aim Restaurant</span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="#"  aria-current="page"><NavLink className="nav-link text-dark" to="/restaurant">
                Restaurant
                </NavLink></a></li>
        <li class="nav-item"><a href="#" ><NavLink className="nav-link text-dark" to="/villes">
                Villes
              </NavLink></a></li>
        <li class="nav-item"><a href="#"><NavLink className="nav-link text-dark" to="/zones">
                Zones
              </NavLink></a></li>
        <li class="nav-item"><a href="#"><NavLink className="nav-link text-dark" to="/series">
                Series
              </NavLink></a></li>
        <li class="nav-item"><a href="#"><NavLink className="nav-link text-dark" to="/specialites">
                Specialite
              </NavLink></a></li>

      </ul>
    </header>
    </div>
  );
}

const Footer = () => {
  return (
    <div>

      <footer class="container-fluid bg-4 text-center">
  <p>Project Made By <a href="#">Aimrane ESSAKHI</a></p> 
</footer>

    </div>
  );
};

export { Header, Footer };
